import RatingTable from './rating-table';

export default RatingTable;
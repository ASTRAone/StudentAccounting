import React, { Component } from 'react';

import './tools.css';

export default class Tools extends Component {
    render() {
        return (
            <div className="tools">
                <i className="fa fa-plus-circle"></i>
                <i className="fa fa-trash"></i>
            </div>
        );
    };
};
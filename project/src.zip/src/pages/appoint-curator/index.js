import AppointCurator from './appoint-curator';

export default AppointCurator;
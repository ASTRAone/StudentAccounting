import RejectCard from './reject-card';

export default RejectCard;
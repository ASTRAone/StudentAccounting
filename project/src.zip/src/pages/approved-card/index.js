import ApprovedCard from './approved-card';

export default ApprovedCard;
import React from 'react';

import './app-header.css';

const AppHeader = () => {

    return (
        <h1 className="app-header">Сервис внутреннего учета студентов-практикантов</h1>
    );
};

export default AppHeader;
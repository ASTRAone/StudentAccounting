import StudentsList from './students-list';

export default StudentsList;
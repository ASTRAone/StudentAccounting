import StudentsListElement from './students-list-element';

export default StudentsListElement;
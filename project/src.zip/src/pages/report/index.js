import Report from './report';

export default Report;

import StudentAddForm from './student-add-form';

export default StudentAddForm;
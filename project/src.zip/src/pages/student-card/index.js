import StudentCard from './student-card';

export default StudentCard;
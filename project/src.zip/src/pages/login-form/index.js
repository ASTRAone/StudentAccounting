import LoginForm from './login-form';

export default LoginForm;
import PageNumbers from './page-numbers';

export default PageNumbers;
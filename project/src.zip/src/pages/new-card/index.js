import NewCard from './new-card';

export default NewCard;
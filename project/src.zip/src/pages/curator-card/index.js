import CuratorCard from './curator-card';

export default CuratorCard;
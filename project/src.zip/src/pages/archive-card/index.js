import ArchiveCard from './archive-card';

export default ArchiveCard;
import MenuItem from './menu-item';

export default MenuItem;
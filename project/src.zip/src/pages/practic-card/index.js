import PracticCard from './practic-card';

export default PracticCard;
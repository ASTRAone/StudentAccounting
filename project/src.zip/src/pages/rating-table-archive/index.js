import RatingTableArchive from './rating-table-archive';

export default RatingTableArchive;
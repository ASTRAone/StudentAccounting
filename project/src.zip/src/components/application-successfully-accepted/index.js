import ApplicationSuccessfullyAccepted from './application-successfully-accepted';

export default ApplicationSuccessfullyAccepted;

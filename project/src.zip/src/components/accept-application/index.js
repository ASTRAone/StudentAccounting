import AcceptApplication from './accept-application';

export default AcceptApplication;
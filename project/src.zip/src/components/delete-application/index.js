import DeleteApplication from './delete-application';

export default DeleteApplication;
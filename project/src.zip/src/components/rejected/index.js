import Rejected from './rejected';

export default Rejected;
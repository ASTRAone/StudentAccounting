import ChangesSaved from './changes-saved';

export default ChangesSaved;
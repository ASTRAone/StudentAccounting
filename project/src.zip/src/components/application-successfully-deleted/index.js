import ApplicationSuccessfullyDeleted from './application-successfully-delete';

export default ApplicationSuccessfullyDeleted;
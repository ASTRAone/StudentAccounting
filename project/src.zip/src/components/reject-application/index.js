import RejectApplication from './reject-application';

export default RejectApplication;